export default function Dashboard() {
    return (
        <section className="page">
            <h1>Admin Dashboard</h1>

        
        </section>
    );
}
